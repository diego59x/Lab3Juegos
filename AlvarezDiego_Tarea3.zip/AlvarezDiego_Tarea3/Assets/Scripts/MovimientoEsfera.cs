﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class MovimientoEsfera : MonoBehaviour
{
    public float force = 0;
    public float jumpForce = 0;
    public AudioClip rodar;
    private int score = 0;
    public Text scoreText;
    int contador = 0;
    Rigidbody rb;
    // Le habia agregado audio pero cuando se creaba la otra peloa
    // No le ponia a esa pelota el sonido entonces mejor se lo quite :/
    // Tambien le habia puesto una camara que se moviera con el mouse
    // pero se movia raro y asi, creo que era por las fuerzas :/
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        scoreText = GameObject.FindGameObjectWithTag("Score").GetComponent<Text>();
    }

    
    void Update()
    {
        if (Input.GetButtonDown("Jump") && Time.timeScale >= 1.0f)
        {
            Jump();
            
        }
        if (scoreText)
        {
            scoreText.text = "Score: " + score.ToString();
        }
    }
   
    private void FixedUpdate()
    {
        if (rb)
        {
            rb.AddForce(Input.GetAxis("Horizontal") * force, 0, Input.GetAxis("Vertical") * force);   
        }

        //RaycastHit hitInfo;


        //if(Physics.Raycast(transform.position, Vector3.down, out hitInfo, 3))
        //{
        //    //Debug.DrawRay(transform.position, Vector3.down *3, Color.green);

        //    if (hitInfo.collider.CompareTag("plane"))
        //        GetComponent<MeshRenderer>().material.color = Color.red;
        //        //Destroy(hitInfo.collider.gameObject);
        //}else
        //    GetComponent<MeshRenderer>().material.color = Color.white;
        ////else
        //{
        //    Debug.DrawRay(transform.position, Vector3.down *3, Color.red);
        //}
    }
    private void Jump()
    {
        if (rb)
            if (Mathf.Abs(rb.velocity.y) < 0.05f)
                rb.AddForce(0, jumpForce, 0, ForceMode.Impulse);
    }
    private void OnCollisionEnter(Collision collision)
    {
      // Si la pelota colsiona con las monedas, las monedas se destruyen
          if (collision.gameObject.CompareTag("Moneda1") || collision.gameObject.CompareTag("Moneda2") || collision.gameObject.CompareTag("Moneda3") || collision.gameObject.CompareTag("Moneda4"))
          {
          
            Destroy(collision.gameObject);
            score += 1;
            contador += 1;
         
          }
          // Si ha destruido las 4 monedas ya no sera destruido por el agua
          if(contador < 3)
          {
            if (collision.gameObject.CompareTag("Agua1") || collision.gameObject.CompareTag("Agua2") || collision.gameObject.CompareTag("Agua3"))

            {
                Destroy(gameObject);
            }
          }
    }
}
