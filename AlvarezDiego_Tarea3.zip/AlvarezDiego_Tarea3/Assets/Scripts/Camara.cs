﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camara : MonoBehaviour
{
    
    //public float sensibilidad;
    //private Transform target;
    //[Range(0, 1)] public float lerpValue;
    //public Vector3 distVec;
    //// en start
    
    // en Update()
    // 
    // Start is called before the first frame update
    void Start()
    {
        //target = GameObject.Find("Jugador").transform;
       
    }

    // Update is called once per frame
    void LateUpdate()
    {
        
            //transform.position = Vector3.Lerp(transform.position, target.position + distVec, lerpValue);
            //distVec = Quaternion.AngleAxis(Input.GetAxis("Mouse X") * sensibilidad, Vector3.up) * distVec;
      
            //transform.LookAt(target);
        
            
    }
}
